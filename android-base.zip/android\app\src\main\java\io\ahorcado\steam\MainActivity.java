package io.ahorcado.steam;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
